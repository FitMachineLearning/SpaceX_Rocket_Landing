from gym.envs.algorithmic.copy_ import CopyEnv
from gym.envs.algorithmic.repeat_copy import RepeatCopyEnv
from gym.envs.algorithmic.duplicated_input import DuplicatedInputEnv
from gym.envs.algorithmic.reverse import ReverseEnv
from gym.envs.algorithmic.reversed_addition import ReversedAdditionEnv
