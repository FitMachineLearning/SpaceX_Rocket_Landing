import gym
import numpy as np

a = np.array([[1,1,1],[2,2,2]])
b = np.array([[3,3,3], [4,4,4]])

af = a.flatten()
bf = b.flatten()

comb = np.array([af,bf])
c = np.arange(np.alen(af))
res = np.zeros(np.alen(af))

for i in range (np.alen(af)):
    res[i] = comb[np.random.randint(0,2),i]

print(res)
fres = res.reshape(2,3)
print("fres",fres)

#print ("res",res)
#for i in range (10):
#    print(np.random.randint(0,3))
