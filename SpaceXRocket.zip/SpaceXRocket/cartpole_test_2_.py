import gym
import numpy as np
import tensorforce
from tensorforce.agents import PPOAgent,TRPOAgent,DDPGAgent
#from tensorforce import Configuration


NUM_GAMES_TO_PLAY = 70000
CLIP_ACTIONS = False #set to true if you want actions to be clipped between [-1,1]

env = gym.make("CartPole-v0")
print("Observations ", env.observation_space, " Actions",env.action_space)

network_config = [{"type": "dense", "size": 64, "activation": "tanh"},
                  {"type": "dense", "size": 64, "activation": "tanh"}]
network_specs  =[
    dict(type='dense', size=32),
    dict(type='dense', size=32),
    dict(type='dense', size=32)
]
critic_network_specs  =[
    dict(type='dense', size=32),
    dict(type='dense', size=32),
    dict(type='dense', size=32)
]
agent = DDPGAgent(states=dict(type='float32', shape=(4,)),
                    actions=dict(type='int', num_actions=2),
                    network=network_specs,
                    update_mode={
                        "unit": "timesteps",
                        "batch_size": 64,
                        "frequency": 64
                    },
                    memory = {
                        "type": "replay",
                        "capacity": 100000,
                        "include_next_states": True
                    },
                    optimizer = {
                        "type": "adam",
                        "learning_rate": 1e-4
                    },
                    discount = 0.99,
                    entropy_regularization = None,
                    critic_network = {
                        "size_t0": 64,
                        "size_t1": 64
                    },
                    critic_optimizer = {
                        "type": "adam",
                        "learning_rate": 1e-3
                    },
                    target_sync_frequency = 1,
                    target_update_weight = 0.999,
                    actions_exploration = {
                        "type": "ornstein_uhlenbeck",
                        "sigma": 0.3,
                        "mu": 0.0,
                        "theta": 0.15
                    },
                    execution = {
                        "type": "single",
                        "session_config": None,
                        "distributed_spec": None
                    }



                    )

allRewards = np.zeros(shape=(1,1))

for game in range(NUM_GAMES_TO_PLAY):
    obs = env.reset()
    gameTotalReward = 0
    for step in range(1000):
        env.render()
        a = agent.act(obs)
        #print("ACTION ->",a)
        if CLIP_ACTIONS:
            for i in range (np.alen(a)):
                if a[i] < -1: a[i]=-0.99999999999
                if a[i] > 1: a[i] = 0.99999999999
        obs, reward, done, info = env.step(a)
        #reward = reward/100
        gameTotalReward = gameTotalReward + reward
        allRewards = np.vstack((allRewards, np.array([reward])))
        if done:
            agent.observe(reward=reward, terminal=True)
        else:
            agent.observe(reward=reward, terminal=False)

        #print("Action: {} Observations Size:{} score: {}".format(a,obs.shape,reward))
        if done:
            print("#",game," last game average ", (gameTotalReward/step)*100,"global avg", allRewards.mean()*100, "max",allRewards.max()*100,"min",allRewards.min()*100 , "steps", step)

            break
