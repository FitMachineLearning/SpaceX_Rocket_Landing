from collections import deque
import numpy as np
from tensorforce import Configuration
from tensorforce.agents.random_agent import RandomAgent
from tensorforce.agents import TRPOAgent
from tensorforce.core.networks import layered_network_builder


env = gym.make("CartPole-v0")

# random_config.observe(reward=a, terminal=True)

actor_network =[
    dict(type='dense', size=32),
    dict(type='dense', size=32),
    dict(type='dense', size=32)
]

trpo_config = Configuration(
    states=dict(type='float32', shape=(4,)),
    actions=dict(type='int', num_actions=2),
    network=actor_network,
)
trpo_agent = TRPOAgent(trpo_config)

rews = deque(maxlen=100)
obs = env.reset()
for _ in range(1000):
    env.render()
    a = trpo_agent.act(obs)
    obs, reward, done, info = env.step(a)
    trpo_agent.observe(reward=reward, terminal=True)
    if done:
        env.reset()
